var totalPeople = 0;
var boyPeople = 0;
var girlPeople = 0;


function getGender() {
    let radioElement = document.getElementsByName("gender");
    for (var i = 0; i < radioElement.length; i++)
        if (radioElement[i].checked) {
            return radioElement[i].value;
        }
    return null;
}

function BabyName() {
    let babyName = document.getElementById("babyName").value;
    let suggester = document.getElementById("suggester").value;

    // Increments the value of girl or boy people
    let gender = getGender();
    if (gender === "Boy") {
        boyPeople++;
        totalPeople++;
    } else if (gender === "Girl") {
        girlPeople++;
        totalPeople++;
    }

displayMessage(suggester, babyName);
displayStats();
displayBorder();
}
function displayMessage(suggester, babyName) {
    let gender = getGender();
    if (gender != null) {
        document.getElementById("Result").innerHTML = suggester + " suggested that it's going to be a baby " + gender +
            " and he/she wants to name " + (gender == "Boy" ? "him " : "her ") + babyName + ". Thank You!";
    }
}
function displayStats() {
    document.getElementById("stats").innerHTML = "Number of people who believe that it's going to be a baby boy = " + boyPeople + "<br />" +
        "Number of people who believe it's going to be a baby girl = " + girlPeople + "<br />" +
        "Total people who voted so far = " + totalPeople;
}
function displayBorder() {
    statsParagraph = document.getElementById("stats");
    statsParagraph.style.borderStyle = "double solid";
    statsParagraph.style.borderColor = "blue";
    statsParagraph.style.textAlign = "center";
    statsParagraph.style.fontFamily = "cursive";
    statsParagraph.style.color = "green";
    statsParagraph.style.fontWeight = "bold";
}
